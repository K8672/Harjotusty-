﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.Common
{
    public enum CardSuit
    {
        Spades = 0,
        Diamonds = 1,
        Hearts = 2,
        Clubs = 3
    }
}
